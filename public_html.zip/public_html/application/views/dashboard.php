

    <div id="page_content">
        <div id="page_content_inner">

            <!-- statistics (small charts) -->
<?php   
    if($this->session->userdata('success'))
                                {   ?>
        <div class="alert alert-success" >
            <?= $this->session->userdata('success'); ?>
        </div>
<?php }  else if($this->session->userdata('failure')){ ?>
            <div class="alert alert-danger">
          <?= $this->session->userdata('failure'); ?>
        </div>
    <?php }   ?>
    
    <div id="desc">
    <p> Hi <?= $user_name ?>.. Here You can see your Users List.</p>
    </div>
   </div>
 </div>

</body>

</html>