<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
     <title>Skrillaz</title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="../../assets/images/skrillaz-logo-png.ico">
     <!-- Datatable -->
    <link href="<?php echo base_url('assets/plugins/datatables/css/jquery.dataTables.min.css'); ?>" rel="stylesheet">
     <!-- Dropify -->
    <link rel="stylesheet" href="<?php echo base_url('assets/plugins/dropify/dist/css/dropify.min.css'); ?>">
 
    <!-- Custom Stylesheet -->
    <link href="<?php echo base_url('assets/main/css/style.css'); ?>" rel="stylesheet">

    <link rel="stylesheet" href="https://lipis.github.io/bootstrap-sweetalert/dist/sweetalert.css" />

    <script src="https://lipis.github.io/bootstrap-sweetalert/dist/sweetalert.js"></script>

</head>

<body>

    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="loader"></div>
    </div>
    <!--*******************
        Preloader end
    ********************-->

    
    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">
      <?php include  $_SERVER['DOCUMENT_ROOT'].'/application/views/admin/layout/menu.php'; ?>

        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">


<?php if($this->session->flashdata('excel_error')) { ?> 

  <div class="alert alert-danger alert-full " role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true"></span></button>
              <center><?php if(!empty($this->session->flashdata('excel_error'))) { 
                #print_r($this->session->flashdata('excel_error')); 
                foreach ($this->session->flashdata('excel_error') as $key => $value) {
                      echo  $value . "<br>"; 
                }  }
               ?></center></div>

<?php } ?>




            <div class="container-fluid">
                <div class="row justify-content-between mb-3">
                    <div class="col-12 text-left">
                        <h2 class="page-heading">List Users</h2>
                    </div>
                  </div>



                 </div>


                  <div class="row">
                  <div class="col-lg-12  col-md-12  col-xxl-12 col-xl-12 ">
                        <div class="card">
                            <div class="card-body">
                             <div class="table-responsive">
                                    <table id="users_table" class="display table table-striped table-bordered" style="min-width: 845px">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>User Name</th>
                                                <th>Email Id</th>
                                                <th>Mobile Number</th>   
                                                <th>Role</th>
                                                <th>Address</th>
                                                <th>Product Categories</th>
                                  <?php if($this->session->userdata("user_role") == ""1) {  ?>             
                                                <th>Action</th>
                                                <?php } ?>
                                            </tr>
                                        </thead>
                                        <tbody>
 <?php $get = $this->Crud_model->get("products", array("status" => 1), "product_id", "desc"); 
if(is_array($get)) {  $t = 1; foreach ($get as $row) {   ?>                                            
                                            <tr>
                                                <td><?= $t ?></td>
                                                <td> <?= $row['user_name'] ?> </td>
                                                <td><?= $row['email_id'] ?></td>
                                                <td><?php if($row['role'] == "1") echo "Admin";
                                                        else echo "User"; ?></td>
                                                <td><?= $row['address'] ?></td>
                                                    <?php if($this->session->userdata("user_role") == ""1) {  ?>       
                                                <td>
                                                    <button onclick="view(<?= $row['user_id'] ?>)" class="btn btn-info" data-toggle="modal" data-target=".view"><i class="fa fa-eye"></i></button>
                                                     <a href="#" class="btn btn-warning"><i class="fa fa-edit"></i></a>
                                                    <button onclick="delette(<?= $row['user_id'] ?>)" class="btn btn-danger"><i class="fa fa-trash"></i></button>
                                                </td>
                                                <?php } ?>

                                            </tr>
                                        <?php $t++;  } }   ?> 
 
                                      </tbody>
                                    </table>
                                </div>
                        </div>
                        </div>

                        
                    </div>
                </div>
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->

       
        

    </div>
    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
   


 


<script src="https://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>
<script src="https://cdn.datatables.net/plug-ins/1.10.21/api/page.jumpToData().js"></script>

  

        <!--End Delete Modal -->
<script type="text/javascript">

  $(document).ready(function() {

    $('#users_table').DataTable( {   });  


});  


    
    function delette(id)
      {
           swal({
            title: "Are you sure to Delete?",
            text: "You will not be able to recover this data!",
            type: "warning",
            showCancelButton: true,
            confirmButtonClass: "btn-danger",
            confirmButtonText: "Yes, delete it!",
            cancelButtonText: "No, cancel pls!",
            closeOnConfirm: false,
            closeOnCancel: false
          },
          function(isConfirm) {
            if (isConfirm) {
              $.ajax({
                 url: '<?= base_url() ?>User/del_user',
                 data : { user_id : id }, 
                 type : "post",
                 error: function() {
                    alert('Something is wrong');
                 },
                 success: function(data) {
                      swal("Deleted!", "Your data has been deleted.", "success");
                      location.reload();
                 }
              });  
            } else {
              swal("Cancelled", "Your data is safe :)", "error");
            }
          });
      }          
    
    


</script>


    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>

  <!--   <script src="<?php echo base_url('assets/plugins/datatables/js/jquery.dataTables.min.js'); ?>"></script> -->
    <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>

</body>
</html>