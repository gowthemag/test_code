
<form action="<?= base_url() ?>Login/register_user" id="user_register" method="post">
  <div class="container">
    <h1>Register</h1>
    <p>Please Include Your Details</p>
    <hr>

    <label for="user_name"><b>User Name</b></label>
    <input type="text" placeholder="Enter User Name" name="user_name" id="user_name" >

    <label for="email"><b>Email Id </b></label>
    <input type="text" placeholder="Enter Email Address" name="email_id"  >
    
    <label><b> Mobile Number </b></label>
    <input type="text" placeholder="Enter Mobile Numebr" name="mobile_no"  >   

    <label ><b> Address </b></label>
    <input type="text" placeholder="Enter Address" name="address"  >  
    
    <label ><b> City </b></label>
    <input type="text" placeholder="Enter City" name="city"  >     

    <label ><b> Pincode </b></label>
    <input type="text" placeholder="Enter Pincode" name="pincode"  >   
    
    <label ><b> Date Of Birth </b></label>
    <input type="date" class="inputField" placeholder="Select D.O.B" name="dob"  >     
    
    <label ><b> Select Role </b></label>
    <select name="role"  class="inputField" >
        <option value="1"> Admin </option>
        <option value="2"> User </option>
    </select>      
    
    <label for="password"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="password" id="password1" >

    <label for="password"><b>Re- Enter Password</b></label>
    <input type="password" placeholder="Re-Enter Password" name="password2" id="password2" >

    <button type="submit" class="btn btn-primary">Submit</button>
  </div>
  
  <div class="container signin">
    <p>Already have an account? <a href="<?= base_url('Login') ?>">Sign in</a>.</p>
  </div>
</form>



  <!-- End Of HTML Page -->

  <!-- Script Tage -->

 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
  <script src="https://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>

<script type="text/javascript">
	
   $("#user_register").validate({

    rules: {
      user_name: {
        required: true,
        remote  : {
            type: 'post',
            url: '<?= base_url() ?>Login/check_name'     
        }        
      },
      email_id: {
        required: true,
        remote  : {
            type: 'post',
            url: '<?= base_url() ?>Login/check_name'     
        }        
      },
      mobile_no: {
        required: true,
        remote  : {
            type: 'post',
            url: '<?= base_url() ?>Login/check_name'     
        }        
      },  
      address: {  required :  true },
      city: {  required :  true },
      pincode: {  required :  true },
      role: {  required :  true },
      dob: {  required :  true },
      password: {  required :  true },
      password2: {
        required: true, equalTo :"#password1"
      },
  	},
      messages : {
      	user_name : {  required : "Please Enter User Name", remote : "User Name Already taken" } ,
      	email_id : {  required : "Please Enter Email Id", remote : "Email Id Already taken" } ,
      mobile_no : {  required : "Please Enter Mobile Number", remote : "Mobile Number Already taken" } ,
      	address : {  required : "Please Enter Address" } ,
      	city : {  required : "Please Enter City" } ,
      	pincode : {  required : "Please Enter Pincode" } ,
      	role : {  required : "Please Select User Role" } ,
      	dob : {  required : "Please Select Data Of Birth" } ,
      	password : {  required : "Please Enter Address" } ,
      	password2 : {   required : "Please Re-Enter Password", equalTo : "Password Must Be Same"  }
      }  
  });





</script>

	<!-- End Of Script Tag -->




</body>
</html>