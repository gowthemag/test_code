
<?php if($this->session->flashdata("failure")) { ?>
<div class="alert alert-danger" role="alert">
    <?php echo $this->session->userdata("failure"); ?>
</div>
<?php } ?>


<?php if($this->session->flashdata("success")) { ?>
<div class="alert alert-success" role="alert">
    <?php echo $this->session->userdata("success"); ?>
</div>
<?php } ?>


<form action="<?= base_url() ?>Login/checkUser" id="user_login" method="post">
  <div class="container">
    <h1>Login</h1>
    <p>Please Login Using Your Credentials.</p>
    <hr>

    <label for="user_name"><b>User Name</b></label>
    <input type="text" placeholder="Enter User Name" name="user_name" id="user_name" required>

    <label for="password"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="password" id="password" required>

    <button type="submit" class="registerbtn">Login</button>
  </div>
  
  <div class="container signin">
    <p>Already have an account? <a href="<?= base_url('Login/register') ?> ">Sign in</a>.</p>
  </div>
</form>



  <!-- End Of HTML Page -->

  <!-- Script Tage -->

 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
  <script src="https://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>

<script type="text/javascript">
	
   $("#user_login").validate({

    rules: {
      user_name: {
        required: true
      },
      password: {
        required: true
      },
  	},
      messages : {
      	user_name : {  required : "Please Enter User Name" } ,
      	password : {   required : "Please Enter Password"  }
      }  
  });





</script>

	<!-- End Of Script Tag -->




</body>
</html>