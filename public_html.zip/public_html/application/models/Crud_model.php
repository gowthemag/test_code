<?php
class Crud_model extends CI_Model{
	public function __construct(){
			parent::__construct();
			$this->load->database();
  
			//  ooooooooooooopppppppppppppppppppeeeeeeeeeeeeennnnnnnnnnnnnnnn bbbbbbbbbbbbbbaaaaaaaaaarrrrrrrrrrr
		}
	public function register($register_data){
		$first_name 	= $register_data->register->first_name;
		$last_name 		= $register_data->register->last_name;
		$mobile_number 	= $register_data->register->mobile_number;
		$email 			= $register_data->register->email;
		$password 		= $register_data->register->password;
		$push_notif_reg_token = $register_data->register->push_notif_reg_token;
		$isFacebookLogin = $register_data->register->isFacebookLogin;
		$isGmailLogin 	 = $register_data->register->isGmailLogin;
		$isNormalLogin 	 = $register_data->register->isNormalLogin;
		$query = $this->db->query("insert into appusers (`user_type`, `first_name`, `last_name`, `mobile_number`, `email`, `password`, `push_notif_reg_token`, `isFacebookLogin`, `isGmailLogin`, `isNormalLogin`,`is_active`)
		         values('customer','$first_name','$last_name','$mobile_number','$email','$password','$push_notif_reg_token','$isFacebookLogin','$isGmailLogin','$isNormalLogin',1)");
			if($query){
				return "success";
			}else{
				return "failed";
			}
	}
	public function login_model($email,$password)
	{
		$this->db->select('*');
		$this->db->from('appusers');
		$this->db->where("email='$email' and password = '$password'");
		$query= $this->db->get();
		return $query;
	}
	public function getpassword($email,$mobile_number)
	{
		$this->db->select('password');
		$this->db->from('appusers');
		$this->db->where("email='$email' and mobile_number = '$mobile_number'");
		$query= $this->db->get();
		return $query;
	}

	function insert($table_name = '', $data=array()){
		$this->db->insert($table_name,$data);
		return $this->db->insert_id();
	}

	// update existing record
	function update($table_name = '', $data=array(),$where=array()){
		$this->db->update($table_name,$data,$where);
	}

	// delete existing record
	function delete($table_name = '', $where=array()){
		$this->db->delete($table_name,$where);
	}

	   function get_count($table_name = '', $where=array())
    {            
            $rs = $this->db->get_where($table_name,$where);

    
            return $rs->num_rows();
    }



    function get_sum($field_name,$table_name='',$where=array()){
     $this->db->select_sum($field_name);
     $this->db->from($table_name);
   $this->db->where($where);
   $query = $this->db->get();
   return $query->row()->$field_name;
    }


	function get($table_name = '', $where=array(),$order_by_field=null,$order_by_order=null,$limit=null,$offset=null)
	{    

		if(!is_null($offset) and !is_null($limit))
		{
			$this->db->limit($limit,$offset);
		}
		if($order_by_field != null and $order_by_order != null)
		{
			$this->db->order_by($order_by_field, $order_by_order);
		}
		if(array_key_exists("customer_group_name",$where))
		{

			$this->db->like($where); 
		 	$rs = $this->db->get($table_name);   
		}
		else
		{
			$rs = $this->db->get_where($table_name,$where);
		}
		

		if($rs->num_rows() > 0)
		{
			return $rs->result_array();
		}
		else
		{
			return false;
		}
	}




	// get list of records for drop down
	function get_list($id_field_name,$value_field_name,$table_name,$init_list=array(),$where=array()){
		$this->db->select($id_field_name);
		$this->db->select($value_field_name);
		$this->db->where($where);
		$rs = $this->db->get($table_name);
		if($rs->num_rows()>0)
		{
			$records = $rs->result_array();
			foreach($records as $record)
			{
				$init_list[$record[$id_field_name]] = $record[$value_field_name];
			}
		}
		return $init_list;
	}
	
	// get one row
	function get_row($table_name,$where=array()){
		$records = $this->get($table_name,$where);
		if($records != false){
			return $records[0];
		}
		else{
			return false;
		}
	}
	// get one field
	function get_one($field_name,$table_name,$where=array()){
		$records = $this->get($table_name,$where);
		if($records != false){
			return $records[0][$field_name];
		}
		else{
			return false;
		}
	}



	function checkDriver($id)
	{
		$this->db->select('*');
		$this->db->from('orders');
		$this->db->where('order_status <', 3);
		$this->db->where('driver_id', $id);
		$qr = $this->db->count_all_results();


		$this->db->select('wallet_amount');
		$this->db->from('user_wallet');
		$this->db->where('user_id', $id);
		$wall = $this->db->get()->result_array();

		//print_r($wall);	

		if(($qr >= 2) || ($wall[0]['wallet_amount'] < -200))
		  return false;
		 else
		   return true; 
	}

	public function calculateAmount($distance, $admin)
	{
		$admin = $admin[0];
		if($distance <= $admin['delivery_min_dist'])  return $admin['delivery_charge'];
		else
		{
			$amount = $admin['delivery_charge'] + ( ($distance - $admin['delivery_min_dist']) * $admin['delivery_per_km']);
			  return $amount;	
		}

	}

	public function getAppId_byOrder($orderId){

		$get = $this->db->query('Select us.app_id as appId from orders as ord join users as us on us.user_id = ord.customer_id and ord.status =1')->result_array();

		echo $get[0]['appId'];

	}

	public function getAppId_byUser($userId){

		$this->db->select('app_id');
		$this->db->from('users');
		$this->db->where('user_id', $userId);
		$get = $this->db->get()->result_array();

		echo $get[0]['app_id'];

	}

	public function getDriverAppId_byUser($userId){

		$this->db->select('app_id');
		$this->db->from('drivers');
		$this->db->where('driver_id', $userId);
		$get = $this->db->get()->result_array();

		echo $get[0]['app_id'];

	}	

}