<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Validate_model extends CI_Model{

	public function __construct(){

			parent::__construct();

			$this->load->database();
		}
	//Declare common variable
	/*public function Fetch_data()
	{
		$validate_array = array('first_nam' => '','last_name' => '');

	}*/

	// To validate every request..
	public function CheckRequestType()
	{
		if(strcasecmp($_SERVER['REQUEST_METHOD'], 'POST') != 0){
			echo json_encode(array('status' => array('status' => 'KO','message' => 'Request method must be POST!'), 'details' => new ArrayObject()));
			return true;
		}
		return false;
	}
	//To check the variable contains all values
	public function CheckParams($decoded,$valid_array)
	{
		foreach ($valid_array as $value) {
			if (!array_key_exists($value, $decoded)) {
				echo json_encode(array('status' => array('status' => 'KO','message' => 'All parameters needed!'), 'details' => new ArrayObject()));
				return true;
			}
		}
	}
	public function StringValidate($str, $errmessage)
	{
		if(strlen($str) == 0)
		{
			echo json_encode(array('status' => array('status' => 'KO','message' => $errmessage), 'details' => new ArrayObject()));
			return true;
		}
		return false;
	}

}