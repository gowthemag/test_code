<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */


	public function index()
	{
		$this->load->view('header');
		$this->load->view('login_page');
	}

	public function register() // to register a new user
	{
		$this->load->view('header');
		$this->load->view('register');
	}	

	public function check_user()  // to check user details is valid or not
	{
		$userName = $_REQUEST['user_name'];
		$password = $_REQUEST['password'];

		$checkArr = array( "user_name" => $userName, "password" => $password, "status" => "1" );
		$check = $this->Crud_model->get("users", $checkArr);

		if(!empty($check))
		{
			$this->session->set_userdata("user_id", $check[0]["user_id"]);
			$this->session->set_userdata("user_role", $check[0]["role"]);
			$this->session->set_flashdata("success", "Successfully Logged In");
			redirect('User/dashboard');
		}
		else 
		{
			$this->session->set_flashdata("failure", "In-Valid User Credentials");
			redirect('Login');
		}
	}

	public function register_user()  // to register new user
	{
	    $dataArr = array (
	            'user_name' => $_REQUEST['user_name'],
	            'mobile_no'   => $_REQUEST['mobile_no'],
	            'email_id'    => $_REQUEST['email_id'],
	            'password'    => $_REQUEST['password'],
	            'address' => $_REQUEST['address'], 
	            'city' => $_REQUEST['city'],
	            'dob' => $_REQUEST['dob'],
	            'role' => $_REQUEST['role'], 
	            'pincode' => $_REQUEST['pincode'], 
	            'date_created' => date('Y-m-d H:i:s')    );

	    $ins = $this->Crud_model->insert("users", $dataArr);

	    if($ins)
	    {
			$this->session->set_flashdata("success", "User Registered Successfully...!");
			redirect('Login');
	    }
	    else 
	    {
			$this->session->set_flashdata("failure", "User Not Registered Successfully...!");
			redirect('Login');
	    }	    	
	}
	
	public function logOut()
	{
	   $this->session->sess_destroy();
	   redirect('Login');
	}
	
	public function check_name()
	{
	    $userName = $_REQUEST['user_name'];
		$checkArr = array( "user_name" => $userName, "status" => "1" );
		$check = $this->Crud_model->get("users", $checkArr);
		
		if(!empty($check)) echo "false";
		else echo "true";
	}

	public function check_email()
	{
	    $email_id = $_REQUEST['email_id'];
		$checkArr = array( "email_id" => $email_id, "status" => "1" );
		$check = $this->Crud_model->get("users", $checkArr);
		
		if(!empty($check)) echo "false";
		else echo "true";
	}

	public function check_mobile()
	{
	    $mobile_no = $_REQUEST['mobile_no'];
		$checkArr = array( "mobile_no" => $mobile_no, "status" => "1" );
		$check = $this->Crud_model->get("users", $checkArr);
		
		if(!empty($check)) echo "false";
		else echo "true";
	}


}
