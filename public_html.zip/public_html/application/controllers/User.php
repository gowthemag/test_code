<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	  public function __construct(){
	    
	    parent::__construct();
	    if(!$this->session->userdata("user_id"))
	    {
			$this->session->set_flashdata("failure", "Please Login to Continue..!");
	    	redirect("Login");
	    }
	  }



	public function index() // user dashboard
	{
		$userId = $this->session->userdata("user_id");
		$data["users"] = $this->Crud_model->get("users", array("user_id" => $userId) );
        $data["user_name"] = $data["users"][0]["user_name"];    
            
		$this->load->view('header');
		$this->load->view('dashboard', $data);
	}

	public function list_users()  // to list active users
	{
		$usersArr = array(  "status" => "1" );
		$data['users'] = $this->Crud_model->get("users", $usersArr);

		$this->load->view("users_list", $data);
	}

	public function get_user_dt()  // to get specific user detail
	{
		$userId = $_REQUEST["user_id"];
		$usersArr = array(  "status" => "1", "user_id" => $userId );
		$get_dt = $this->Crud_model->get("users", $usersArr);

		echo json_encode($get_dt);
	}

	public function del_user()  // to change active status of specific user
	{
		$userId = $_REQUEST["user_id"];
		$dataArr = array(  "status" => "0" );  $userArr = array("user_id" => $userId );
		$up_dt = $this->Crud_model->update("users", $dataArr, $usersArr);

		echo "1";
	}


	public function update_user()  // to update user
	{
	    $dataArr = array (
	            'user_name' => $_REQUEST['user_name'],
	            'mobile_no'   => $_REQUEST['mobile_no'],
	            'email_id'    => $_REQUEST['email_id'],
	            'password'    => $_REQUEST['password'],
	            'address' => $_REQUEST['address'], 
	            'city' => $_REQUEST['city'], 
	            'pincode' => $_REQUEST['pincode']   );

	    $userArr = array("user_id" => $_REQUEST["user_id"] ); 

	    $up = $this->Crud_model->update("users", $dataArr, $userArr);

		$this->session->set_flashdata("success", "User Updated Successfully...!");
		redirect('User/list_users');
   	
	}



}
